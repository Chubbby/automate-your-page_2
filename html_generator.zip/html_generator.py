Python 2.7.9 (default, Dec 10 2014, 12:24:55) [MSC v.1500 32 bit (Intel)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> def generate_concept_HTML(concept_title, concept_description):
    html_text_1 = '''
<div class="concept">
    <div class="concept-title">
        ''' + concept_title
    html_text_2 = '''
    </div>
    <div class="concept-description">
        ''' + concept_description
    html_text_3 = '''
    </div>
</div>'''
    full_html_text = html_text_1 + html_text_2 + html_text_3
    return full_html_text

>>> def make_HTML(concept):
    concept_title = concept[0]
    concept_description = concept[1]
    return generate_concept_HTML(concept_title, concept_description)

>>> LIST_OF_CONCEPTS = [ ['Programming Functions', 'Once a function is defined then it can be called on used over and over, this helps avoid repetition'],
                             ['LOOPS', 'Allowing code to repeat an action'],
                     ['Strings and List', 'A string will contain characters but a list contains characters, numbers, or lists']]
>>> def make_HTML_for_many_concepts(list_of_concepts):
    HTML = ""
    for concept in list_of_concepts:
        concept_HTML = make_HTML(concept)
        HTML = HTML + concept_HTML
    return HTML

>>> print make_HTML_for_many_concepts(LIST_OF_CONCEPTS)

<div class="concept">
    <div class="concept-title">
        Programming Functions
    </div>
    <div class="concept-description">
        Once a function is defined then it can be called on used over and over, this helps avoid repetition
    </div>
</div>
<div class="concept">
    <div class="concept-title">
        LOOPS
    </div>
    <div class="concept-description">
        Allowing code to repeat an action
    </div>
</div>
<div class="concept">
    <div class="concept-title">
        Strings and List
    </div>
    <div class="concept-description">
        A string will contain characters but a list contains characters, numbers, or lists
    </div>
</div>
>>> 
